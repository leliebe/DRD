        <div class="footer" id="footer">
            <p class="ftext"> Copyright 2020 - Last updated 9 October 2020</p>
        </div>
    </div><!--close drd-page tag in head.php-->
</body>
</html>
