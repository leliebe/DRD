<?php
class Dbconfig {
    protected $serverName;
    protected $userName;
    protected $passCode;
    protected $dbName;

    function Dbconfig() {
        $dbname = 'restora1_DRD';
$dbuser = 'restora1_leliebe';
$dbpass = 'Merm9!87rl1';
$dbhost = 'localhost';
    }
}
?>
