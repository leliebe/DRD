<?php
    //manipulate data
    $name = $_POST['auth_name'];
    echo "Got: " . $name;
?>
