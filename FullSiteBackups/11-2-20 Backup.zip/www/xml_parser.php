<?php
function parse_xml_file($file_name)
{
    $file_name = '../XML/' . $file_name;
    //echo $file_name;
    $xml = simplexml_load_file($file_name) or die("Error: Cannot create object");
    // echo $xml;
    
// Get the sufix for tags
    $docTitleatt = $xml->text->front->titlePage->docTitle;
    $atts_object = $docTitleatt->attributes();
    $atts_array = (array) $atts_object;
    $atts_array = $atts_array['@attributes'];
    $docTitleref = $atts_array['ref'];
    $dTref = substr($docTitleref, -3);    
    echo "$dTref";
//$tagSuffix
//####################################  TEST CODE ###################################
//                        Only works with Anonymous - Andronicus 
//        echo "<div class='full_play'>";
        foreach ($xml->text->front->titlePage as $titlePage)
        {

            foreach ($titlePage->testTag1 as $testTag1)
            {
                foreach($testTag1->titlePartMain as $titlePartMain)
                {
                    foreach($titlePartMain->line as $titlePartMainline)
                    {
                        $atts_object = $titlePartMainline->attributes(); //- get all attributes, this is not a real array
                        $atts_array = (array) $atts_object; //- typecast to an array
                        
                        //- grab the value of '@attributes' key, which contains the array your after
                        $atts_array = $atts_array['@attributes'];
                        
                        // var_dump($atts_object); //- outputs object(SimpleXMLElement)[19]
                                                //-             public '@attributes' => ...
                        
                        // var_dump($atts_array); //- outputs array (size=11) ...
                        $attr = $atts_array['font'];
                        $attr .= " " . $atts_array['color'];
                        $attr .= " " . $atts_array['style'];
                        echo $attr;
                   
                        echo "<p style=$attr class='test1'>$titlePartMainline</p>";
                        
                    }
                    foreach($titlePartMain->hr as $hr)
                    {
                        $atts_object = $hr->attributes(); //- get all attributes, this is not a real array
                        $atts_array = (array) $atts_object; //- typecast to an array
                        
                        $atts_array = $atts_array['@attributes'];
                        
                        $attrcl = $atts_array['class'].$hr;
                        $attrid = $atts_array['id'].$hr;

                        echo "<hr/ class=$attrcl id=$attrid>";
                    }
                }
                foreach($testTag1->titlePartSub as $titlePartSub)
                {
                    foreach($titlePartSub->line as $titlePartSubline)
                    {
                        $atts_object = $titlePartSubline->attributes(); //- get all attributes, this is not a real array
                        $atts_array = (array) $atts_object; //- typecast to an array
                        
                        $atts_array = $atts_array['@attributes'];
                        
                        $attrcl = $atts_array['class'];
                        $attrid = $atts_array['id'];

                        echo "<p style=$attr2 class='test2'>$titlePartSubline</p>";
                        
                    }
                    foreach($titlePartSub->hr as $hr)
                    {
                        $atts_object = $hr->attributes(); //- get all attributes, this is not a real array
                        $atts_array = (array) $atts_object; //- typecast to an array
                        
                        $atts_array = $atts_array['@attributes'];
                        
                        $attrcl = $atts_array['class'].$hr;
                        $attrid = $atts_array['id'].$hr;

                        echo "<hr/ class=$attrcl id=$attrid>";
                    }
                }
                foreach($testTag1->titlePartDesc as $titlePartDesc)
                {
                    foreach($titlePartDesc->line as $titlePartDescline)
                    {
                        $atts_object = $titlePartDescline->attributes(); //- get all attributes, this is not a real array
                        $atts_array = (array) $atts_object; //- typecast to an array
                        
                        $atts_array = $atts_array['@attributes'];
                        
                        // var_dump($atts_object); //- outputs object(SimpleXMLElement)[19]
                                                //-             public '@attributes' => ...
                        
                        // var_dump($atts_array); //- outputs array (size=11) ...
                        $attrcl = $atts_array['class'];
                        $attrid = $atts_array['id'];
                        echo $attr;
                   
                        echo "<p class=$attrcl id=$attrid>$titlePartDescline</p>";
                        
                    }
                    foreach($titlePartDesc->hr as $hr)
                    {
                        $hr_class = "hr".$hr;
                        echo "<div class=$hr_class>";
                        echo "<hr/>";
                        echo "</div>";
                    }
                }
            }

        }
//        echo "</div>"; //end of full_play
    // }
    
//####################################  TEST CODE ###################################

    echo "<div class='docTitle'>";
    foreach ($xml->text->front->titlePage as $titlePage)
    {
        foreach ($titlePage->docTitle as $docTitle)
        {
            foreach($docTitle->titlePartMain as $titlePartMain)
            {
                foreach($titlePartMain->line as $titlePartMainline)
                {
                    $atts_object = $titlePartMainline->attributes(); //- get all attributes, this is not a real array
                    $atts_array = (array) $atts_object; //- typecast to an array
                    $atts_array = $atts_array['@attributes'];
                    
                    $attrcl = $atts_array['class'];
                    $attrid = $atts_array['id'];

                    echo "<p class=$attrcl id=$attrid>$titlePartMainline</p>";
                }
            }
            
            foreach($docTitle->titlePartSub as $titlePartSub)
            {
                foreach($titlePartSub->line as $titlePartSubline)
                {
                    $atts_object = $titlePartSubline->attributes(); //- get all attributes, this is not a real array
                    $atts_array = (array) $atts_object; //- typecast to an array
                    $atts_array = $atts_array['@attributes'];
                    
                    $attrcl = $atts_array['class'];
                    $attrid = $atts_array['id'];

                    echo "<p class=$attrcl id=$attrid>$titlePartSubline</p>";
                }
            }
            
            foreach($docTitle->titlePartDesc as $tpd)
            {
                foreach($tpd->line as $tpdline)
                {
                    $atts_object = $tpdline->attributes(); //- get all attributes, this is not a real array
                    $atts_array = (array) $atts_object; //- typecast to an array
                    $atts_array = $atts_array['@attributes'];
                    
                    $attrcl = $atts_array['class'];
                    $attrid = $atts_array['id'];

                    echo "<p class=$attrcl id=$attrid>$tpdline</p>";
                    
                    foreach($tpdline->name as $tpdlname)
                    {
                        $atts_object = $tpdlname->attributes(); //- get all attributes, this is not a real array
                        $atts_array = (array) $atts_object; //- typecast to an array
                        $atts_array = $atts_array['@attributes'];
                        
                        $attrcl = $atts_array['class'];
                        $attrid = $atts_array['id'];
                        
                        echo "<p class=$attrcl id=$attrid>$tpdlname</p>";
                    }
                }
            }
            
            // foreach($docTitle->titlePartMain as $titlePartMain)
            // {
            //     if ($titlePartMain->count() == 0)
            //     {
            //         echo "<p class='drd_h1'><h1>$titlePartMain</h1></p>";
            //     }
            //     foreach($titlePartMain->line as $titlePartMainline)
            //     {
            //         foreach($titlePartMainline->h1 as $h1)
            //         {
            //             echo "<p class='drd_h1'><h1>$h1</h1></p>";
            //         }
            //         foreach($titlePartMainline->h2 as $h2)
            //         {
            //             echo "<p class='drd_h2'><h1>$h2</h2></p>";
            //         }
            //         foreach($titlePartMainline->h3 as $h3)
            //         {
            //             echo "<p class='drd_h3'><h3>$h3</h3></p>";
            //         }
            //         foreach($titlePartMainline->h4 as $h4)
            //         {
            //             echo "<p class='drd_h4'><h4>$h4</h4></p>";
            //         }
            //         foreach($titlePartMainline->h5 as $h5)
            //         {
            //             echo "<p class='drd_h5'><h5>$h5</h5></p>";
            //         }
            //         foreach($titlePartMainline->h6 as $h6)
            //         {
            //             echo "<p class='drd_h6'><h6>$h6</h6></p>";
            //         }
            //   }
            // }
            
            // foreach($docTitle->titlePartSub as $titlePartSub)
            // {
            //     foreach($titlePartSub->line as $titlePartSubline)
            //     {
            //         foreach($titlePartSubline->h1 as $h1)
            //         {
            //             echo "<p class='drd_h1'><h1>$h1</h1></p>";
            //         }
            //          foreach($titlePartSubline->h2 as $h2)
            //         {
            //             echo "<p class='drd_h2'><h1>$h2</h2></p>";
            //         }
            //         foreach($titlePartSubline->h3 as $h3)
            //         {
            //             echo "<p class='drd_h3'><h3>$h3</h3></p>";
            //         }
            //         foreach($titlePartSubline->h4 as $h4)
            //         {
            //             echo "<p class='drd_h4'><h4>$h4</h4></p>";
            //         }
            //         foreach($titlePartSubline->h5 as $h5)
            //         {
            //             echo "<p class='drd_h5'><h5>$h5</h5></p>";
            //         }
            //         foreach($titlePartSubline->h6 as $h6)
            //         {
            //             echo "<p class='drd_h6'><h6>$h6</h6></p>";
            //         }
            //     }
            // }
            // foreach($docTitle->titlePartDesc as $titlePartDesc)
            // {
            //     foreach($titlePartDesc->line as $titlePartDescline)
            //     {
            //         foreach($titlePartSubline->h1 as $h1)
            //         {
            //             echo "<p class='drd_h1'><h1>$h1</h1></p>";
            //         }
            //         foreach($titlePartDescline->h2 as $h2)
            //         {
            //             echo "<p class='drd_h2'><h2>$h2</h2></p>";
            //         }
            //         foreach($titlePartDescline->h3 as $h3)
            //         {
            //             echo "<p class='drd_h3'><h3>$h3</h3></p>";
            //         }
            //         foreach($titlePartDescline->h4 as $h4)
            //         {
            //             echo "<p class='drd_h4'><h4>$h4</h4></p>";
            //         }
            //         foreach($titlePartDescline->h5 as $h5)
            //         {
            //             echo "<p class='drd_h5'><h5>$h5</h5></p>";
            //         }
            //         foreach($titlePartDescline->h6 as $h6)
            //         {
            //             echo "<p class='drd_h5'><h6>$h6</h6></p>";
            //         }
            //         foreach($titlePartDescline->name as $tpdname)
            //         {
            //             echo "<p class='tpdname'><i>$tpdname->italic</i></p>";
            //         }
            //     }
            // }
        }
        foreach($docTitle->hr as $hr)
        {
            $atts_object = $hr->attributes(); //- get all attributes, this is not a real array
            $atts_array = (array) $atts_object; //- typecast to an array
            
            $atts_array = $atts_array['@attributes'];
            
            $attrcl = $atts_array['class'].$hr;
            $attrid = $atts_array['id'].$hr;

            echo "<hr/ class=$attrcl id=$attrid>";
        }
    }
    echo "</div>";//close div docTitle


    echo "<div class='byline'>";
    foreach ($xml->text->front->titlePage->byline as $byline)
    {
        foreach($byline->line as $bylineline)
        {
            foreach($bylineline->seg as $bylinelineseg)
            {
                $writtenby .= $bylinelineseg;
                foreach($bylinelineseg->docAuthor as $docAuthor)
                {
                    foreach($docAuthor->name as $dAname)
                    {
                        $atts_object = $dAname->attributes(); //- get all attributes, this is not a real array
                        $atts_array = (array) $atts_object; //- typecast to an array
                        $atts_array = $atts_array['@attributes'];
                        
                        $format = $atts_array['rend'];
                        switch ($format) 
                        {
                            case 'italic':
                                $dAname = "<i>$dAname</i>";
                                break;
                            case 'bold':
                                $dAname = "<b>$dAname</b>";
                                break;
                            case 'bold-italic':
                                $dAname = "<b><i>$dAname</i></b>";
                                break;
                            default:
                                break;
                        } 
                            
                        $writtenby .= $dAname;
                    }
                }        
            }
            echo "<p>$writtenby</p>";
        }
        foreach($byline->hr as $hr)
        {
            $atts_object = $hr->attributes(); //- get all attributes, this is not a real array
            $atts_array = (array) $atts_object; //- typecast to an array
            
            $atts_array = $atts_array['@attributes'];
            
            $attrcl = $atts_array['class'].$hr;
            $attrid = $atts_array['id'].$hr;

            echo "<hr/ class=$attrcl id=$attrid>";
        }
    }
    echo "</div>";//close div byline

    echo "<div class='epigraph'>";
    foreach ($xml->text->front->titlePage->epigraph as $epigraph)
    {
        foreach($epigraph->p as $epigraph_p)
        {
            foreach($epigraph_p->line as $epigraph_pline)
            {
                $atts_object = $epigraph_pline->attributes(); //- get all attributes, this is not a real array
                $atts_array = (array) $atts_object; //- typecast to an array
                $atts_array = $atts_array['@attributes'];
                
                $format = $atts_array['rend'];
                switch ($format) 
                {
                    case 'italic':
                        $epigraph_pline = "<i>$epigraph_pline</i>";
                        break;
                    case 'bold':
                        $epigraph_pline = "<b>$epigraph_pline</b>";
                        break;
                    case 'bold-italic':
                        $epigraph_pline = "<b><i>$epigraph_pline</i></b>";
                        break;
                    default:
                        break;
                } 

                echo "<p>$epigraph_pline</p>";
                
                foreach($epigraph_pline->seg as $epigraph_plineseg)
                {
                    $epi_line .= $epigraph_plineseg;
                    $atts_object = $epigraph_plineseg->attributes(); //- get all attributes, this is not a real array
                    $atts_array = (array) $atts_object; //- typecast to an array
                    $atts_array = $atts_array['@attributes'];
                    
                    $format = $atts_array['rend'];
                    switch ($format) 
                    {
                        case 'italic':
                            $epi_line = "<i>$epi_line</i>";
                            break;
                        case 'bold':
                            $epi_line = "<b>$epi_line</b>";
                            break;
                        case 'bold-italic':
                            $epi_line = "<b><i>$epi_line</i></b>";
                            break;
                        default:
                            break;
                    } 
                    foreach($epigraph_plineseg->bibl as $epigraph_plinesegbibl)
                    {
                        $epi_line .= $epigraph_plinesegbibl;
                        foreach($epigraph_plinesegbibl->seg as $epigraph_plinesegbiblseg)
                        {
                            foreach($epigraph_plinesegbiblseg->author as $epi_author)
                            {
                                $epi_line .= $epi_author;
                            }
                            foreach($epigraph_plinesegbiblseg->title as $epi_title)
                            {
                                $epi_line .= $epi_title;
                            }
                            foreach($epigraph_plinesegbiblseg->biblScope as $epi_biblScope)
                            {
                                $epi_line .= $epi_biblScope;
                            }
                        }
                    }
                }
                echo "<p class='epli'>$epi_line</p>";
            }
        }
        foreach($epigraph->hr as $hr)
        {
            $atts_object = $hr->attributes(); //- get all attributes, this is not a real array
            $atts_array = (array) $atts_object; //- typecast to an array
            
            $atts_array = $atts_array['@attributes'];
            
            $attrcl = $atts_array['class'].$hr;
            $attrid = $atts_array['id'].$hr;

            echo "<hr/ class=$attrcl id=$attrid>";
        }
    }
    echo "</div>";//close epigraph

    echo "<div class='imprimatur'>";
    foreach ($xml->text->front->titlePage->imprimatur as $imprimatur)
    {
        foreach($imprimatur->line as $imprimaturline)
        {
            if ($imprimaturline->count() == 0)
            {
                $imprima = $imprimaturline;
            }
            foreach($imprimaturline->seg as $imprimaturlineseg)
            {
                $atts_object = $imprimaturlineseg->attributes(); //- get all attributes, this is not a real array
                $atts_array = (array) $atts_object; //- typecast to an array
                $atts_array = $atts_array['@attributes'];
                
                $format = $atts_array['rend'];
                switch ($format) 
                {
                    case 'italic':
                        $imprimaturlineseg = "<i>$imprimaturlineseg</i>";
                        break;
                    case 'bold':
                        $imprimaturlineseg = "<b>$imprimaturlineseg</b>";
                        break;
                    case 'bold-italic':
                        $imprimaturlineseg = "<b><i>$imprimaturlineseg</i></b>";
                        break;
                    default:
                        break;
                } 
                $imprima .= $imprimaturlineseg;
            }
            echo "<p>$imprima</p>";
            $imprima = "";
        }
        foreach($imprimatur->hr as $hr)
        {
            $atts_object = $hr->attributes(); //- get all attributes, this is not a real array
            $atts_array = (array) $atts_object; //- typecast to an array
            
            $atts_array = $atts_array['@attributes'];
            
            $attrcl = $atts_array['class'].$hr;
            $attrid = $atts_array['id'].$hr;

            echo "<hr/ class=$attrcl id=$attrid>";
        }
    }
    echo "</div>";//close imprimatur

    echo "<div class='docImprint'>";
    foreach($xml->text->front->titlePage->docImprint as $docImp)
    {
        foreach($docImp->line as $diline)
        {
            if ($diline->count() == 0)
            {
                $di_line = $diline;
            }
            foreach($diline->seg as $diliseg)
            {
                $atts_object = $diliseg->attributes(); //- get all attributes, this is not a real array
                $atts_array = (array) $atts_object; //- typecast to an array
                $atts_array = $atts_array['@attributes'];
                
                $format = $atts_array['rend'];
                switch ($format) 
                {
                    case 'italic':
                        $diliseg = "<i>$diliseg</i>";
                        break;
                    case 'bold':
                        $diliseg = "<b>$diliseg</b>";
                        break;
                    case 'bold-italic':
                        $diliseg = "<b><i>$diliseg</i></b>";
                        break;
                    default:
                        break;
                } 
                $di_line .= $diliseg;
                foreach($diliseg->placeName as $dilisegpn)
                {
                    $atts_object = $dilisegpn->attributes(); //- get all attributes, this is not a real array
                    $atts_array = (array) $atts_object; //- typecast to an array
                    $atts_array = $atts_array['@attributes'];
                    
                    $format = $atts_array['rend'];
                    switch ($format) 
                    {
                        case 'italic':
                            $dilisegpn = "<i>$dilisegpn</i>";
                            break;
                        case 'bold':
                            $dilisegpn = "<b>$dilisegpn</b>";
                            break;
                        case 'bold-italic':
                            $dilisegpn = "<b><i>$dilisegpn</i></b>";
                            break;
                        default:
                            break;
                    } 
                    $di_line .= $dilisegpn;
                }
                foreach($diliseg->name as $dilisegname)
                {
                    $atts_object = $dilisegname->attributes(); //- get all attributes, this is not a real array
                    $atts_array = (array) $atts_object; //- typecast to an array
                    $atts_array = $atts_array['@attributes'];
                    
                    $format = $atts_array['rend'];
                    switch ($format) 
                    {
                        case 'italic':
                            $dilisegname = "<i>$dilisegname</i>";
                            break;
                        case 'bold':
                            $dilisegname = "<b>$dilisegname</b>";
                            break;
                        case 'bold-italic':
                            $dilisegname = "<b><i>$dilisegname</i></b>";
                            break;
                        default:
                            break;
                    } 
                    $di_line .= $dilisegname;
                }
                foreach($diliseg->date as $dilisegdate)
                {
                    $atts_object = $dilisegdate->attributes(); //- get all attributes, this is not a real array
                    $atts_array = (array) $atts_object; //- typecast to an array
                    $atts_array = $atts_array['@attributes'];
                    
                    $format = $atts_array['rend'];
                    switch ($format) 
                    {
                        case 'italic':
                            $dilisegdate = "<i>$dilisegdate</i>";
                            break;
                        case 'bold':
                            $dilisegdate = "<b>$dilisegdate</b>";
                            break;
                        case 'bold-italic':
                            $dilisegdate = "<b><i>$dilisegdate</i></b>";
                            break;
                        default:
                            break;
                    } 
                    $di_line .= $dilisegdate;
                }
            }
            echo "<p>$di_line</p>";
            $di_line = "";
        }
        foreach($docImp->hr as $hr)
        {
            $atts_object = $hr->attributes(); //- get all attributes, this is not a real array
            $atts_array = (array) $atts_object; //- typecast to an array
            
            $atts_array = $atts_array['@attributes'];
            
            $attrcl = $atts_array['class'].$hr;
            $attrid = $atts_array['id'].$hr;

            echo "<hr/ class=$attrcl id=$attrid>";
        }
    }
    echo "</div>";//close docImprint
    
    //End titlePage

    echo "<div class='cldiv'>";
    foreach($xml->text->front->castList as $castList)
    {
        $attrcl = "";
        $attrid = "";
        if ($castList->attributes())
        {
            $atts_object = $castList->attributes(); //- get all attributes, this is not a real array
            $atts_array = (array) $atts_object; //- typecast to an array
            $atts_array = $atts_array['@attributes'];
            
            $attrcl = "class=".$atts_array['class'];
            $attrid = "id=".$atts_array['id'];
        }
        
        if ($castList->count() == 0)
        {
            echo "<p $attrcl $attrid>$castList</p>";
        }
        foreach($castList->head as $castlisthead)
        {
            $attrcl = "";
            $attrid = "";
            if ($castlisthead->attributes())
            {
                $atts_object = $castlisthead->attributes(); //- get all attributes, this is not a real array
                $atts_array = (array) $atts_object; //- typecast to an array
                $atts_array = $atts_array['@attributes'];
                
                $attrcl = "class=".$atts_array['class'];
                $attrid = "id=".$atts_array['id'];
            }
            
            if ($castlisthead->count() == 0)
            {
                echo "<p $attrcl $attrid>$castlisthead</p>";
            }
        }
        foreach($castList->castGroup as $clcastgroup)
        {
            $attrcl = "";
            $attrid = "";
            if ($clcastgroup->attributes())
            {
                $atts_object = $clcastgroup->attributes(); //- get all attributes, this is not a real array
                $atts_array = (array) $atts_object; //- typecast to an array
                $atts_array = $atts_array['@attributes'];
                
                $attrcl = "class=".$atts_array['class'];
                $attrid = "id=".$atts_array['id'];
            }
            
            if ($clcastgroup->count() == 0)
            {
                echo "<p $attrcl $attrid>$clcastgroup</p>";
            }
            foreach($clcastgroup->head as $clcastgrouphead)
            {
                $attrcl = "";
                $attrid = "";
                if ($clcastgrouphead->attributes())
                {
                    $atts_object = $clcastgrouphead->attributes(); //- get all attributes, this is not a real array
                    $atts_array = (array) $atts_object; //- typecast to an array
                    $atts_array = $atts_array['@attributes'];
                    
                    $attrcl = "class=".$atts_array['class'];
                    $attrid = "id=".$atts_array['id'];
                }
                
                if ($clcastgrouphead->count() == 0)
                {
                    echo "<p $attrcl $attrid>$clcastgrouphead</p>";
                }
            }
            foreach($clcastgroup->castGroup as $clcgcg)
            {
                $attrcl = "";
                $attrid = "";
                if ($clcgcg->attributes())
                {
                    $atts_object = $clcgcg->attributes(); //- get all attributes, this is not a real array
                    $atts_array = (array) $atts_object; //- typecast to an array
                    $atts_array = $atts_array['@attributes'];
                    
                    $attrcl = "class=".$atts_array['class'];
                    $attrid = "id=".$atts_array['id'];
                }
                
                if ($clcgcg->count() == 0)
                {
                    echo "<p $attrcl $attrid>$clcgcg</p>";
                }
                foreach($clcgcg->castItem as $clcgcgci)
                {
                    $attrcl = "";
                    $attrid = "";
                    if ($clcgcgci->attributes())
                    {
                        $atts_object = $clcgcgci->attributes(); //- get all attributes, this is not a real array
                        $atts_array = (array) $atts_object; //- typecast to an array
                        $atts_array = $atts_array['@attributes'];
                        
                        $attrcl = "class=".$atts_array['class'];
                        $attrid = "id=".$atts_array['id'];
                    }
                    
                    if ($clcgcgci->count() == 0)
                    {
                        echo "<p $attrcl $attrid>$clcgcgci</p>";
                    }
                    foreach($clcgcgci->castItem as $clcgcgcici)
                    {
                        $attrcl = "";
                        $attrid = "";
                        if ($clcgcgcici->attributes())
                        {
                            $atts_object = $clcgcgcici->attributes(); //- get all attributes, this is not a real array
                            $atts_array = (array) $atts_object; //- typecast to an array
                            $atts_array = $atts_array['@attributes'];
                            
                            $attrcl = "class=".$atts_array['class'];
                            $attrid = "id=".$atts_array['id'];
                        }
                        
                        if ($clcgcgcici->count() == 0)
                        {
                            echo "<p $attrcl $attrid>$clcgcgcici</p>";
                        }
                        foreach($clcgcgcici->role as $clcgcgcicirole)
                        {
                            $attrcl = "";
                            $attrid = "";
                            if ($clcgcgcicirole->attributes())
                            {
                                $atts_object = $clcgcgcicirole->attributes(); //- get all attributes, this is not a real array
                                $atts_array = (array) $atts_object; //- typecast to an array
                                $atts_array = $atts_array['@attributes'];
                                
                                $attrcl = "class=".$atts_array['class'];
                                $attrid = "id=".$atts_array['id'];
                            }
                            
                            if ($clcgcgcicirole->count() == 0)
                            {
                                echo "<p $attrcl $attrid>$clcgcgcicirole</p>";
                            }
                            foreach($clcgcgcicirole->line as $clcgcgcicirline)
                            {
                                $attrcl = "";
                                $attrid = "";
                                if ($clcgcgcicirline->attributes())
                                {
                                    $atts_object = $clcgcgcicirline->attributes(); //- get all attributes, this is not a real array
                                    $atts_array = (array) $atts_object; //- typecast to an array
                                    $atts_array = $atts_array['@attributes'];
                                    
                                    $attrcl = "class=".$atts_array['class'];
                                    $attrid = "id=".$atts_array['id'];
                                }
                                
                                if ($clcgcgcicirline->count() == 0)
                                {
                                    echo "<p $attrcl $attrid>$clcgcgcicirline</p>";
                                }
                                foreach($clcgcgcicirline->seg as $clcgcgcicirlseg)
                                {
                                    $atts_object = $clcgcgcicirlseg->attributes(); //- get all attributes, this is not a real array
                                    $atts_array = (array) $atts_object; //- typecast to an array
                                    $atts_array = $atts_array['@attributes'];
                                    
                                    $format = $atts_array['rend'];
                                    switch ($format) 
                                    {
                                        case 'italic':
                                            $clcgcgcicirlseg = "<i>$clcgcgcicirlseg</i>";
                                            break;
                                        case 'bold':
                                            $clcgcgcicirlseg = "<b>$clcgcgcicirlseg</b>";
                                            break;
                                        case 'bold-italic':
                                            $clcgcgcicirlseg = "<b><i>$clcgcgcicirlseg</i></b>";
                                            break;
                                        default:
                                            break;
                                    } 
                                    $di_line .= $clcgcgcicirlseg;
                                    foreach($clcgcgcicirlseg->name as $clcgcgcicirlsname)
                                    {
                                        $atts_object = $clcgcgcicirlsname->attributes(); //- get all attributes, this is not a real array
                                        $atts_array = (array) $atts_object; //- typecast to an array
                                        $atts_array = $atts_array['@attributes'];
                                        
                                        $format = $atts_array['rend'];
                                        switch ($format) 
                                        {
                                            case 'italic':
                                                $clcgcgcicirlsname = "<i>$clcgcgcicirlsname</i>";
                                                break;
                                            case 'bold':
                                                $clcgcgcicirlsname = "<b>$clcgcgcicirlsname</b>";
                                                break;
                                            case 'bold-italic':
                                                $clcgcgcicirlsname = "<b><i>$clcgcgcicirlsname</i></b>";
                                                break;
                                            default:
                                                break;
                                        } 
                                        $di_line .= $clcgcgcicirlsname;
                                    }
                                }
                                echo "<p>$di_line</p>";
                                $di_line = "";
                            }
                        }
                        foreach($clcgcgcicirole->name as $clcgcgcicirname)
                        {
                            $atts_object = $clcgcgcicirname->attributes(); //- get all attributes, this is not a real array
                            $atts_array = (array) $atts_object; //- typecast to an array
                            $atts_array = $atts_array['@attributes'];
                            
                            $format = $atts_array['rend'];
                            switch ($format) 
                            {
                                case 'italic':
                                    $clcgcgcicirname = "<i>$clcgcgcicirname</i>";
                                    break;
                                case 'bold':
                                    $clcgcgcicirname = "<b>$clcgcgcicirname</b>";
                                    break;
                                case 'bold-italic':
                                    $clcgcgcicirname = "<b><i>$clcgcgcicirname</i></b>";
                                    break;
                                default:
                                    break;
                            } 
                            $di_line .= $clcgcgcicirname;
                        }
                        // if ($clcgcgcicirname->count() == 0)
                        // {
                        //     echo "<p>$di_line</p>";
                        //     $di_line = "";
                        // }
                        
                        
                        foreach($clcgcgcici->roleDesc as $clcgcgcicird)
                        {
                            $attrcl = "";
                            $attrid = "";
                            if ($clcgcgcicird->attributes())
                            {
                                $atts_object = $clcgcgcicird->attributes(); //- get all attributes, this is not a real array
                                $atts_array = (array) $atts_object; //- typecast to an array
                                $atts_array = $atts_array['@attributes'];
                                
                                $attrcl = "class=".$atts_array['class'];
                                $attrid = "id=".$atts_array['id'];
                            }
                            
                            if ($clcgcgcicird->count() == 0)
                            {
                                echo "<p $attrcl $attrid>$clcgcgcicird</p>";
                            }
                            foreach($clcgcgcicird->line as $clcgcgcicirdline)
                            {
                                // $attrcl = "";
                                // $attrid = "";
                                if ($clcgcgcicirdline->count() == 0)
                                {
                                if ($clcgcgcicirdline->attributes())
                                {
                                    $atts_object = $clcgcgcicirdline->attributes(); //- get all attributes, this is not a real array
                                    $atts_array = (array) $atts_object; //- typecast to an array
                                    $atts_array = $atts_array['@attributes'];
                                    
                                    $format = $atts_array['rend'];
                                    switch ($format) 
                                    {
                                        case 'italic':
                                            $clcgcgcicirdline = "<i>$clcgcgcicirdline</i>";
                                            break;
                                        case 'bold':
                                            $clcgcgcicirdline = "<b>$clcgcgcicirdline</b>";
                                            break;
                                        case 'bold-italic':
                                            $clcgcgcicirdline = "<b><i>$clcgcgcicirdline</i></b>";
                                            break;
                                        default:
                                            break;
                                    } 
                                }
                                
                                    echo "<p>$clcgcgcicirdline</p>";
                                }
                                foreach($clcgcgcicirdline->seg as $clcgcgcicirdlseg)
                                {
                                    $atts_object = $clcgcgcicirdlseg->attributes(); //- get all attributes, this is not a real array
                                    $atts_array = (array) $atts_object; //- typecast to an array
                                    $atts_array = $atts_array['@attributes'];
                                    
                                    $format = $atts_array['rend'];
                                    switch ($format) 
                                    {
                                        case 'italic':
                                            $clcgcgcicirdlseg = "<i>$clcgcgcicirdlseg</i>";
                                            break;
                                        case 'bold':
                                            $clcgcgcicirdlseg = "<b>$clcgcgcicirdlseg</b>";
                                            break;
                                        case 'bold-italic':
                                            $clcgcgcicirdlseg = "<b><i>$clcgcgcicirdlseg</i></b>";
                                            break;
                                        default:
                                            break;
                                    } 
                                    $di_line .= $clcgcgcicirdlseg;
                                }
                                echo "<p>$di_line</p>";
                                $di_line = "";
                            }
                        }
                    }
                }
            }
        }
    }
    echo "</div>";// end castlist

    echo "<div class='salute'>";
    foreach($xml->text->front->salute as $salute )
    {
        echo "<div class='salhead'>";
        foreach($salute->head as $salhead)
        {
            $attrcl = "";
            $attrid = "";
            if ($salhead->attributes())
            {
                $atts_object = $salhead->attributes(); //- get all attributes, this is not a real array
                $atts_array = (array) $atts_object; //- typecast to an array
                $atts_array = $atts_array['@attributes'];
                
                $attrcl = "class=".$atts_array['class'];
                $attrid = "id=".$atts_array['id'];
            }

            if ($salhead->count() == 0)
            {
                echo "<p $attrcl $attrid>$salhead</p>";
            }
            
            foreach($salhead->line as $salheadline)
            {
                $attrcl = "";
                $attrid = "";
                if ($salheadline->attributes())
                {
                    $atts_object = $salheadline->attributes(); //- get all attributes, this is not a real array
                    $atts_array = (array) $atts_object; //- typecast to an array
                    $atts_array = $atts_array['@attributes'];
                    
                    $attrcl = "class=".$atts_array['class'];
                    $attrid = "id=".$atts_array['id'];
                }
                
                echo "<p $attrcl $attrid>$salheadline</p>";
            }
            
            foreach($salhead->name as $salhname)
            {
                $attrcl = "";
                $attrid = "";
                if ($salhname->attributes())
                {
                    $atts_object = $salhname->attributes(); //- get all attributes, this is not a real array
                    $atts_array = (array) $atts_object; //- typecast to an array
                    $atts_array = $atts_array['@attributes'];
                    
                    $attrcl = "class=".$atts_array['class'];
                    $attrid = "id=".$atts_array['id'];
                }
                
                if ($salhname->count() == 0)
                {
                    echo "<p $attrcl $attrid>$salhname</p>";
                }
                foreach($salhname->line as $salhnameline)
                {
                    $attrcl = "";
                    $attrid = "";
                    if ($salhnameline->attributes())
                    {
                        $atts_object = $salhnameline->attributes(); //- get all attributes, this is not a real array
                        $atts_array = (array) $atts_object; //- typecast to an array
                        $atts_array = $atts_array['@attributes'];
                        
                        $attrcl = "class=".$atts_array['class'];
                        $attrid = "id=".$atts_array['id'];
                    }
                    
                    echo "<p $attrcl $attrid>$salhnameline</p>";
                }
            }
        }
        echo "</div>";// end salute head'
        echo "<div class='saladd'>";
        foreach($salute->address as $saladd)
        {
            $attrcl = "";
            $attrid = "";
            if ($saladd->attributes())
            {
                $atts_object = $saladd->attributes(); //- get all attributes, this is not a real array
                $atts_array = (array) $atts_object; //- typecast to an array
                $atts_array = $atts_array['@attributes'];
            
                $attrcl = "class=".$atts_array['class'];
                $attrid = "id=".$atts_array['id'];
            }

            if ($saladd->count() == 0)
            {
                echo "<p $attrcl $attrid>$saladd</p>";
            }
        }
        echo "</div>";// end salute address'
        echo "<div class='salp'>";
        foreach($salute->p as $salutep)
        {
            $attrcl = "";
            $attrid = "";
            if ($salutep->attributes())
            {
                $atts_object = $salutep->attributes(); //- get all attributes, this is not a real array
                $atts_array = (array) $atts_object; //- typecast to an array
                $atts_array = $atts_array['@attributes'];
                
                $attrcl = "class=".$atts_array['class'];
                $attrid = "id=".$atts_array['id'];
            }
            
            if ($salutep->count() == 0)
            {
                echo "<p $attrcl $attrid>$salutep</p>";
            }
            
            foreach($salutep->line as $salutepline)
            {
                $attrcl = "";
                $attrid = "";
                if ($salutepline->attributes())
                {
                    $atts_object = $salutepline->attributes(); //- get all attributes, this is not a real array
                    $atts_array = (array) $atts_object; //- typecast to an array
                    $atts_array = $atts_array['@attributes'];
                    
                    $attrcl = "class=".$atts_array['class'];
                    $attrid = "id=".$atts_array['id'];
                }
                
                if ($salutepline->count() == 0)
                {
                    echo "<p $attrcl $attrid>$salutepline</p>";
                }
                foreach($salutepline->seg as $saluteplineseg)
                {
                    if ($saluteplineseg->count() == 0)
                    {
                        $atts_object = $saluteplineseg->attributes(); //- get all attributes, this is not a real array
                        $atts_array = (array) $atts_object; //- typecast to an array
                        $atts_array = $atts_array['@attributes'];
                        
                        $format = $atts_array['rend'];
                        switch ($format) 
                        {
                            case 'italic':
                                $saluteplineseg = "<i>$saluteplineseg</i>";
                                break;
                            case 'bold':
                                $saluteplineseg = "<b>$saluteplineseg</b>";
                                break;
                            case 'bold-italic':
                                $saluteplineseg = "<b><i>$saluteplineseg</i></b>";
                                break;
                            default:
                                break;
                        } 
                        $salute_line .= $saluteplineseg;
                    }
                    foreach($saluteplineseg->name as $saluteplinesegname)
                    {
                        $atts_object = $saluteplinesegname->attributes(); //- get all attributes, this is not a real array
                        $atts_array = (array) $atts_object; //- typecast to an array
                        $atts_array = $atts_array['@attributes'];
                        
                        $format = $atts_array['rend'];
                        switch ($format) 
                        {
                            case 'italic':
                                $saluteplinesegname = "<i>$saluteplinesegname</i>";
                                break;
                            case 'bold':
                                $saluteplinesegname = "<b>$saluteplinesegname</b>";
                                break;
                            case 'bold-italic':
                                $saluteplinesegname = "<b><i>$saluteplinesegname</i></b>";
                                break;
                            default:
                                break;
                        } 
                        $salute_line .= $saluteplinesegname;
                    }
                }
                if ($salute_line)
                {
                    echo "<p>$salute_line</p>";
                    $salute_line = "";
                }
            }
        }
        echo "</div>";// end salute p'
        echo "<div class='salcl'>";
        foreach($salute->closing as $salclose)
        {
            $attrcl = "";
            $attrid = "";
            if ($salclose->attributes())
            {
                $atts_object = $salclose->attributes(); //- get all attributes, this is not a real array
                $atts_array = (array) $atts_object; //- typecast to an array
                $atts_array = $atts_array['@attributes'];
                
                $attrcl = "class=".$atts_array['class'];
                $attrid = "id=".$atts_array['id'];
            }

            if ($salclose->count() == 0)
            {
                echo "<p $attrcl $attrid>$salclose</p>";
            }
            foreach($salclose->line as $salcline)
            {
                $attrcl = "";
                $attrid = "";
                if ($salcline->attributes())
                {
                    $atts_object = $salcline->attributes(); //- get all attributes, this is not a real array
                    $atts_array = (array) $atts_object; //- typecast to an array
                    $atts_array = $atts_array['@attributes'];
                    
                    $attrcl = "class=".$atts_array['class'];
                    $attrid = "id=".$atts_array['id'];
                }
    
                if ($salcline->count() == 0)
                {
                    echo "<p $attrcl $attrid>$salcline</p>";
                }
            }
            foreach($salcline->name as $salclinename)
            {
                $attrcl = "";
                $attrid = "";
                if ($salclinename->attributes())
                {
                    $atts_object = $salclinename->attributes(); //- get all attributes, this is not a real array
                    $atts_array = (array) $atts_object; //- typecast to an array
                    $atts_array = $atts_array['@attributes'];
                    
                    $attrcl = "class=".$atts_array['class'];
                    $attrid = "id=".$atts_array['id'];
                }
    
                if ($salclinename->count() == 0)
                {
                    echo "<p $attrcl $attrid>$salclinename</p>";
                }
            }
        }
        echo "</div>"; //end salute closing
    }
    echo "</div>";//close salute

    // echo "<div class='outerCG$cg1cnt'>";

    //     echo "<div class='outerCGhead$cg1cnt'>";
    //     if ($castGroup1->head)
    //     {
    //         $cg1h = $castGroup1->head;
    //         echo "<p class='cghead'>$cg1h</p>";
    //     }
    //     echo "</div>";

    //     foreach($castGroup1->castGroup as $castGroup2)
    //     {
    //         echo "<div class='innerCG$cg2cnt'>";
    //         foreach($castGroup2->castItem as $castItemGrp)
    //         {
    //             if ($divCntItem == 1)
    //             {
    //                 echo "<div class='$cg1h$roleGrpCnt'>";

    //             }
    //             echo "<div class='castItemGrp$roleGrpCnt'>";
    //             foreach ($castItemGrp->castItem as $castItem)
    //             {
    //                 if ($castItem->role->name)
    //                 {
    //                     $cItem = $castItem->role->name;
    //                     $castItem .=  "<p class='ciname'>$cItem</p>";
    //                     echo $castItem;
    //                 }
    //                 if ($castItem->roleDesc != null)
    //                 {
    //                     $divCntItem = 0;
    //                     echo "</div>";
    //                 }

    //                 if ($castItem->roleDesc->italic)
    //                 {
    //                     $rDesc = $castItem->roleDesc->italic;
    //                     $roleDesc = "<p class='rdesc1'>$rDesc</p>";
    //                     if ($castItem->roleDesc->seg)
    //                     {
    //                         $rDesc = $castItem->roleDesc->seg;
    //                         $roleDesc .= "<p class='rdesc2'>$rDesc</p>";
    //                     }
    //                     if ($castItem->roleDesc->seg[1]->italic)
    //                     {
    //                         $rDesc = $castItem->roleDesc->seg[1]->italic;
    //                         $roleDesc .= "<p class='rdesc3'>$rDesc</p>";
    //                     }
    //                     $roleDesc = "<div class='roleDesc$roleGrpCnt'>$roleDesc</div><br>";
    //                     echo $roleDesc;
    //                 }
    //                 if ($castItem->seg)
    //                 {
    //                     foreach($castItem->seg as $ciSeg)
    //                     {
    //                         // echo $ciSeg;
    //                         // $ciSeg = $castItem->seg[$segCnt];
    //                         $castSeg .= "<p class='seg$segCnt'>$ciSeg</p>";
    //                         $segCnt++;
    //                     }
    //                     $castSeg = "<div class='segDiv$roleGrpCnt'>$castSeg</div><br>";
    //                     echo $castSeg;
    //                 }
    //                 if ($castItem->castItem)
    //                 {
    //                 foreach ($castItem->castItem as $cII)
    //                 {
    //                     if ($cII->role->name)
    //                     {
    //                         $cIIrole = $cII->role->name;
    //                         echo "<div class='ciirole'>$cIIrole</div>";
    //                     }
    //                     if ($cII->roleDesc->italic)
    //                     {
    //                         $cIIdesc = $cII->roleDesc->italic;
    //                         echo "<div class='ciiroledesc'>$cIIdesc</div>";
    //                     }
    //                 }
    //                 }
    //                 $divCntItem++;
    //                 $roleGrpCnt++;

    //             }
    //             echo "</div>";
    //         }
    //         $cg2cnt++;
    //         echo "</div>";
    //     }
    //     $cg1cnt++;
    //     echo "</div>";
    // }
    // echo "</div>";

    // echo "<div class='hrset'>";
    // echo "<hr/>";
    // echo "</div>";

    echo "<div class='set'>";

    $set1 = $xml->text->front->set->seg[0];
    $set2 = $xml->text->front->set->italic;
    $set3 = $xml->text->front->set->seg[1];
    $set = $set1 . ' ' . $set2 . $set3;
    $set = "<p class='set1'>$set</p>";
    // $set .= "<p class='set2'>$set2</p>";
    // $set .= "<p class='rdesc1'>$set3</p>";

    echo $set;

    echo "</div>";//close set


// Start Salute

    // echo "<div class='hrsalute'>";
    // echo "<hr/>";
    // echo "</div>";

    // echo "<div class='salute'>";

    // $saltitle = $xml->text->front->salute->title->p;

    // $saltitle = "<p class='set1'>$saltitle</p>";

    // echo $saltitle;

    // foreach ($xml->text->front->salute->p as $salute)
    // foreach ($xml->text->front->salute->p as $salute)
    // {
    //     if ($salute->persName)
    //     {
    //         $salpersName = $salute->persName;
    //         $salpersName = "<p class='salpersName'>$salpersName</p>";
    //     }
    //     foreach ($salute->seg as $salSeg)
    //     {
    //         $salText .= $salSeg;
    //         if ($salSeg->italic)
    //         {
    //             $salText .= "<i>$salSeg->italic</i>";
    //         }
    //     }
    // }
    // echo "<div class='spName'>";
    // echo $salpersName;
    // echo "</div>";//close spName

    // echo "<div class='salTextDiv'>";
    // echo "<p class='salText'>";
    // echo $salText;
    // echo "</p>";
    // echo "</div>";//close salTextDiv

    // echo "</div>";//close salute


    //
    //Prolog goes HERE
    //
    // echo "<div class='hrpbody'>";
    // echo "<hr/>";
    // echo "</div>";
    // foreach ($xml->text->front as $front)
    foreach ($xml->text->front as $front)
    {
        foreach ($front->prologue as $prologue)
        {
            foreach ($prologue->head as $proHead)
            {
                // echo "GOT PROLOGUE <br>";
            }
        }
        foreach ($front->epilogue as $epilogue)
        {
            foreach ($epilogue->head as $epiHead)
            {
                // echo "GOT EPILOGUE <br>";
            }
        }
    }
// Start of Play Body
    $stagecnt = 0;
    // foreach ($xml->text->body as $playBody)
    foreach ($xml->text->body as $playBody)
    {
        foreach ($playBody->div as $pBodyDiv)
        {
            foreach ($pBodyDiv->head as $pBDHead)
            {
                foreach ($pBDHead->italic as $pBDHeadHi)
                {
                    // echo "<div class='hract'>";
                    // echo "<hr/>";
                    // echo "</div>";

                    $act = "<div class='act'><h1>$pBDHeadHi</h1></div>";
                    echo $act;
                    foreach ($pBDHead->stage as $pBDHeadStage)
                    {
                        $stagecnt++;
                        echo "<div class='stagegrp$stagecnt'>";
                        foreach ($pBDHeadStage->seg as $pBDHStageSeg)
                        {
                            foreach ($pBDHStageSeg->seg as $pBDHStageSeg2)
                            {
                                //$StageS2 = $pBDHStageSeg2;
                                $StageSeg2 .= $pBDHStageSeg2;
                                foreach ($pBDHStageSeg2->name as $pBDHStageName)
                                {
                                    // $stageNm = $pBDHStageName;
                                    $StageName = "<i>$pBDHStageName</i>";
                                    $StageSeg2 .= $StageName;
                                }
                                foreach ($pBDHStageSeg2->italic as $pBDHStageHi)
                                {
                                    // $stgHi = $pBDHStageHi;
                                    $StageHi = "<i>$pBDHStageHi</i>";
                                    $StageSeg2 .= $StageHi;
                                }
                            }
                        }
                        echo "<p class='stage'>$StageSeg2</p>";
                        $StageSeg2 = "";
                        echo "</div>";
                    }
                }

            }
            foreach ($pBodyDiv->sp as $pBSp)
            {
                foreach ($pBSp->stage as $pBSpStage)
                {
                    echo "<div class='innerstage'>";
                    echo $pBSpStage;
                    foreach ($pBSpStage->seg as $pBSpStageSeg)
                    {
                        echo $pBSpStageSeg;
                        foreach ($pBSpStageSeg->seg as $pBSpStageSegSeg)
                        {
                            echo $pBSpStageSegSeg;
                            foreach ($pBSpStageSegSeg->name as $pBSpStageSSName)
                            {
                                echo "<i>$pBSpStageSSName</i>";

                            }
                            foreach ($pBSpStageSegSeg->italic as $pBSpStageSSHi)
                            {
                                echo "<i>$pBSpStageSSHi</i>";

                            }

                        }
                        foreach ($pBSpStageSeg->name as $pBSpStageSegName)
                        {
                            echo "<i>$pBSpStageSegName</i>";

                        }

                    }
                    echo "</div>";
                }

                foreach ($pBSp->speaker as $pBSpSpeaker)
                {
                    echo "<div class='speaker'><i>$pBSpSpeaker->name</i></div>";
                }

                echo "<div class='spText'>";
                foreach ($pBSp->l as $pBSpLine)
                {
                    if ($pBSpLine->seg->count() == 0 && $pBSpLine->stage->count() == 0)
                    {
                        echo "$pBSpLine<br>";
                    }
                    foreach ($pBSpLine->seg as $pBSpLineSeg)
                    {
                        $spLs = $pBSpLineSeg;
                        $lineSeg .= $spLs;
                        foreach ($pBSpLineSeg->name as $pBSpLineSegName)
                        {
                            $lineSeg .= $pBSpLineSegName;

                        }
                        foreach ($pBSpLineSeg->italic as $pBSpLineSegHi)
                        {
                            $lineSeg .= $pBSpLineSegHi;
                        }
                    }
                    if ($lineSeg != "" && $lineSeg != null)
                    {
                        echo "$lineSeg<br>";
                    }
                    $lineSeg = "";
                    foreach ($pBSpLine->stage as $pBSpLineStage)
                    {
                        $stageDir = $pBSpLineStage;
                        foreach ($pBSpLineStage->seg as $pBSpLStageSeg)
                        {
                            $stageDir .= $pBSpLStageSeg;
                        }
                        echo "<div class='innerstage'>$stageDir</div>";
                    }

                }
                echo "</div>";

            }

        }
    }
//    }//End of TEI


}//end of function parse_xml_file
?>
