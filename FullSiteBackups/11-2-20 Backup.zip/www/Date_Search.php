<?php include('head.php'); ?>

<div class="content">
    <!-- Code for page goes here  -->
    <p> This page will display a full list of play texts available, with links
      to both web-viewable and downloadable pdf versions by Date. More complex searches will rely on the
      "search" function. </p>
</div>
<?php include('footer.php'); ?>
