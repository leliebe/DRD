<div class = "navigate" id="nav">
<div class="nav-title" id="nav-title">Digital Restoration Drama</div>
<div class="nav-links">
	<a id="home" class="active" href="index.php">Home</a>
	<a id="adv-search" href="DRD_Adv_Search.php">Advanced Search</a>
	<a id="browse" href="browse.php">Browse</a> <!-- Make sure we're using the right link -->
	<a id="recent" href="">Recently Added</a> <!-- Needs link -->
	<a id="about" href="DRD_About.php">About Us</a>
	<div class="night-mode" id="night-mode">
		<input type="checkbox" class="checkbox" id="night-check" onclick="dark()">
		<label for="night-check" class="label">
			<span class="dark">Dark</span>
			<span class="light">Light</span>
			<div class="blob"></div>
		</label>
	</div>
	<a href="javascript:void(0);" class="icon" onclick="">
		<i class="fa fa-bars"></i>
	</a>
</div>
</div>