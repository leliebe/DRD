<?php include('head.php'); ?>

<div class="content">
<!-- Code for page goes here  -->
    <p>Digital Restoration Drama is managed by Lauren Liebe, a doctoral candidate in English at Texas A&M University. She can be contacted
        <a href="mailto:leliebe@tamu.edu">here.</a></p>
</div>
<?php include('footer.php'); ?>
