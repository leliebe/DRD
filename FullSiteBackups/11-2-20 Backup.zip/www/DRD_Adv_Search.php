<!DOCTYPE html>
<?php include('head.php'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<div class="content Adv-search" id="content">
	<h2 style="text-align:center; margin-bottom:0;">Advanced Search</h2>
<!--<p> This is the search page. </p>-->
	<form>
		<button type="button" class="collapsible" id="play-info" onclick="collapse()">Play Info</button>
		<section class="accordian"> <!-- Play Information Section -->
			<section class="form-section">
				<div class="form-div">
					<label for="play-title">Title</label>
					<input type="text" id="play-title" name="play-title">
				</div>
				<div class="form-div">
					<label for="author">Author</label>
					<input type="text" id="author" name="author">
				</div>
				<div class="form-div">
					<label for="set-location">Setting - Location</label>
					<input type="text" id="set-location" name="set-location">
				</div>
				<br style="clear:both;" />
			</section>
			<section class="form-section">				
				<div class="form-div">
					<label for="set-time">Setting-Time</label>
					<input type="text" id="set-time" name="set-time">
				</div>
				<div class="form-div">
					<label for="genre">Genre</label>
					<select id="genre" name="genre">
						<option value="tragedy">Tragedy</option>
						<option value="comedy">Comedy</option>
					</select>
				</div>
				<br style="clear:both;" />
			</section>
		</section>

		<button type="button" class="collapsible" id="pub-info" onclick="collapse()">Publication</button>
		<section class="accordian"> <!-- Publication Section -->
			<section class="form-section">
				<div class="form-div">
					<label for="publisher">Publisher</label>
					<input type="text" id="publisher" name="publisher">
				</div>
				<div class="form-div">
					<label for="printer">Printer</label>
					<input type="text" id="printer" name="printer">
				</div>
				<div class="form-div">
					<label for="print-location">Print Location</label>
					<input type="text" id="print-location" name="print-location">
				</div>
				<br style="clear:both;" />
			</section>
			<section class="form-section">
				<div class="form-div">
					<label for="book-sign">Bookseller's Sign</label>
					<input type="text" id="book-sign" name="book-sign">
				</div>
				<div class="form-div">
					<label for="pub-date">Pub. Date</label>
					<input type="text" id="pub-date" name="pub-date">
				</div>
				<br style="clear:both;" />
			</section>
		</section>

		<button type="button" class="collapsible" id="perform-info" onclick="collapse()">Performance</button>
		<section class="accordian"> <!-- Performance Section -->
			<section class="form-section">
				<div class="form-div">
					<label for="theatre">Theatre</label>
					<select id="theatre" name="theatre">
						<option value="at-court">At Court</option>
						<option value="barth-fair">Bartholomew Fair</option>
						<option value="covent-garden">Covent Garden</option>
						<option value="cockpit">The Cockpit Theatre</option>
						<option value="dorset-garden">Dorset Garden Theatre</option>
						<option value="drury-lane">Drury Lane Theatre</option>
						<option value="lincoln-inn">Lincoln's Inn Fields Theatre</option>
						<option value="red-bull">Red Bull Theatre</option>
						<option value="salisbury">Salisbury Court</option>
						<option value="southwark">Southwark Fair</option>
						<option value="vere-street">Vere Street Theatre</option>
						<option value="other">Other/Unknown</option>
					</select>
				</div>
				<div class="form-div">
					<label for="performer">Performer</label>
					<input type="text" id="performer" name="performer">
				</div>
				<div class="form-div">
					<label for="play-company">Playing Company</label>
					<select id="play-company" name="play-company">
						<option value="king-company">King's Company</option>
						<option value="duke-company">Duke's Company</option>
						<option value="united-company">United Company</option>
						<option value="other">Other/Unknown</option>
					</select>
				</div>
				<br style="clear:both;" />
			</section>
			<section class="form-section">
				<div class="form-div">
					<label for="perform-date">Date</label>
					<input type="text" id="perform-date" name="perform-date">
				</div>
				<div class="form-div">
					<label for="perform-date-picker">Date</label>
					<input type="date" id="perform-date-picker" name="perform-date-picker" value="1660-01-01" min="1659-01-01" max="1686-01-01">
				</div>
				<br style="clear:both;" />
			</section>
		</section>

		<button type="button" class="collapsible" id="para-text" onclick="collapse()">Paratext</button>
		<section class="accordian"> <!-- Paratext Section -->
			<section class="form-section">
				<div class="form-div">
					<label for="para-author">Author</label>
					<input type="text" id="para-author" name="para-author">
				</div>
				<div class="form-div">
					<label for="para-date">Date</label>
					<input type="text" id="para-date" name="para-date">
				</div>
				<div class="form-div">
					<label for="para-type">Type</label>
					<select id="para-type" name="para-type">
						<option value="bookseller">Bookseller's Lists</option>
						<option value="prologue">Prologue</option>
						<option value="epilogue">Epilogue</option>
						<option value="epistle">Dedicatory Epistle</option>
						<option value="letter">Letter to the Reader</option>
						<option value="essay">Essay</option>
					</select>
				</div>
				<br style="clear:both;" />
			</section>
		</section>
		<section class="form-btn">
			<button type="submit" id="search-btn">Search</button>
		</section>
	</form>
	<!-- script for handling collapsible areas -->
	<script> 
	var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("opened");
    var content = this.nextElementSibling;
    if (content.style.maxHeight){
      content.style.maxHeight = null;
    } else {
      content.style.maxHeight = content.scrollHeight + "px";
    } 
  });
}
</script>
</div>
<?php include('footer.php'); ?>
