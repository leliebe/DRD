<?php include('head.php'); ?>

<!-- Code for page goes here  -->
<!--Code for search bar-->
<section class="hero">
	<div class="container">
			<div class="search">
				<form>
					<input class="input" type="text" name="s" placeholder="Find a Play . . .">
					<button type="submit">Search</button>
				</form>
			</div>
	</div>
	<div class="hero-image" title="This image is a part of the LUNA: Folger Bindings Image Collection"></div>
</section>
<div class="home-content" id ="content">
	<div class="intro">
	    <h1>Under Construction!</h1>
	    <p>This project is still in active development, and the current version is primarily for testing and proof-of-concept purposes. Many elements of the site are currently non-functional or semi-functional. Please contact us with any questions or concerns <a href=mailto: "digitalrestorationdrama@gmail.com">here</a>. The site will be changing frequently within the next few months, so check back often!</p>
	</div>
	<div class="btn-container">
		<div class="quicklink" id="link-1">
			<img src="./CSS/RecentlyAdded_Image.jpg">
			<p>Recently Added</p>
		</div>
		<div class="quicklink" id="link-2">
			<img src="./CSS/FeaturedWork_Image.jpg">
			<p>Featured Work</p>
		</div>
		<div class="quicklink" id="link-3">
		<img src="./CSS/RelatedProjects_Image.jpg">
			<p>Related Projects</p>
		</div>
	</div>
 <!--   <div class="update-left">
        <div class="upper-left">
            <div class="home-title">
              <h1>Welcome to Digital Restoration Drama</h1>
            </div>
            <p class="intro">
                Digital Restoration Drama seeks to expand electronic access to plays from the English
                  Restoration. Currently, the project is limited to plays performed, printed, or written
                  between 1660 and 1685, covering the reign of Charles II. Though initial phases have largely
                  focused on commercially produced plays performed in London theaters, there are plans to
                  extend the site’s coverage to include closet and manuscript drama and plays produced for
                  the Smock Alley Theater in Dublin.
            </p>
            <p class="intro">
              Designed as a supplement to projects such as <a href="https://digitalrenaissance.uvic.ca/">Digital Renaissance Editions</a>,
              the <a href="https://londonstagedatabase.usu.edu/">London Stage Database</a>, and
              the Folger Shakespeare Library’s <a href="https://earlymodernenglishdrama.folger.edu/">Digital Anthology of Early Modern English Drama</a>,
              Digital Restoration Drama offers TEI-encoded, lightly-edited, full-text editions of plays,
              supported by metadata reflecting the publication and performance histories of each text.
            </p>
        </div><!--close upper-left div-->

  <!--      <div class="divider">
            <hr/>
        </div>
        <div class="update-lower">
            <h2>Updates</h2>
            <div class="home-update-text">
                <p class="up-txt-r">
                    Our most recent addition is George Villiers, Duke of Buckingham's <i>The Chances</i>, an adaptation of John Fletcher's play of the same name. This play marks the start of a tradition of nobles reworking Fletcher's plays, which would become particularly important during the Tory response of the post-Exclusion Crisis years. 
                   <!--OLD: We've added the full text of Edward Ravenscroft's <i>Titus Andronicus; or, The Rape of Lavinia</i>!
                          This adaptation of Shakespeare's <i>Titus Andronicus</i> premiered during the Popish Plot. While it largely
                          follows Shakespeare's source text (although Ravenscroft begins the long-standing trend of denying Shakespeare's)
                          authorship, it also demonstrates its Restoration roots through its emphasis on visual spectacle, culminating in
                          a final banquet scene that surpasses its Shakespearean predecessor. Find the full text here-->
 <!--              </p>
            </div>
        </div>
    </div> -->
    <!-- <section class="twitter">
      <div class="twit-header">
        <img src="./images/Twitter_Logo/Twitter_Logo_WhiteOnImage.png">
      </div> -->
      <!--<div class="home-twiter"> -->
        <!-- <div class="twitter-content"> -->
          <!--  <a class="twitter-timeline" href="https://twitter.com/L_E_Liebe?ref_src=twsrc%5Etfw">Tweets by L_E_Liebe</a>
            <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script> -->
        <!-- </div> -->
        <!-- <img src="./images/Twitter_Logo_WhiteOnImage.png"> -->
        <!-- Twiter -->
      <!--</div>
    <!-- </section> -->
</div>
<?php include('footer.php'); ?>
