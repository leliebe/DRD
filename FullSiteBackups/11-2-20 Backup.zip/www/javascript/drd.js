// $(function () { //Get authors on page load.
// 	if($('.content').is('.Author_Search')){
// 		// alert("Author_Search");
// 		$.ajax({
// 		    type: "POST",
// 		    url: './database/db_query.php',
// 		    data: {query_name: "Authors"},
// 		    success: function(data){
// 					// $('.auth-pl-plays').html(data);
// 					// for (var i=0;i<data.length;i++){
// 					//    option += '<option value="'+ data[i] + '">' + data[i] + '</option>';
// 					// }
// 					// $('.auth-pl-plays').append(option);
// 			}
// 		});
// 	}
// });

// var $dropdown = $(".auth-sel");
// $.each(result, function() {
//     $dropdown.append($("<option />").val(this.ImageFolderID).text(this.Name));
// });



// Get all plays by author last name.
function qry_plays(){
	var author = $.trim($(".auth-sel :selected").text()).split(',');
	var author_lname = $.trim(author[0]);
	var author_fname = $.trim(author[1]);
	var author_name = author[1] + " " + author[0];
	$('.aplaname').html(author_name);
	$('.aplheading').html('List of Plays:');
	$.ajax({
	    type: "POST",
	    url: './database/db_query.php',
		data: {function_name: 'get_plays',
			   field1: author_fname,
			   field2: author_lname
		   	  },
	    success: function(data){
			$('.auth-pl-plays').html(data);
	    }
	});
}

// function qry_play_text(){
// 	var author = $.trim($(".auth-sel :selected").text()).split(',');
// 	var author_lname = $.trim(author[0]);
// 	var author_fname = $.trim(author[1]);
// 	var author_name = author[1] + " " + author[0];
// 	$('.aplaname').html(author_name);
// 	$('.aplheading').html('List of Plays:');
// 	$.ajax({
// 	    type: "POST",
// 	    url: './database/db_query.php',
// 		data: {function_name: 'get_play_text',
// 			   field1: author_fname,
// 			   field2: author_lname
// 		   	  },
// 	    success: function(data){
// 			$('.auth-pl-plays').html(data);
// 	    }
// 	});
// }

$(function () {
	$('.auth-pl-plays').on('click', 'a', function () {
		var play_title = $(this).text();
// 		alert(play_title);
		// $('.apltitle').html(play_title);
		$.ajax({
		    type: "POST",
		    url: './database/db_query.php',
			data: {function_name: 'get_play_text',
				   field1: play_title
			   	  },
		    success: function(data){
				// alert(data);    <script src="./javascript/drd.js"></script>
                // $('head').append( $('<link rel="stylesheet" type="text/css" />').attr('href', './CSS/Anon_Andronicus.css') );

				$('.auth-play').html(data);
		    }
		});
	});
});

// function qry_title(){
// 	$.ajax({
// 		type: "POST",
// 		url: './database/db_query.php',
// 		data: {query_name: "Titles"},
// 		success: function(data){
// 				$('.results').html(data);
// 	    }
// 	});
// }

// DARK MODE CODE -- IN PROGRESS

let darkMode = localStorage.getItem("darkMode");
var hoverIndex;

function dark() {
    //console.log("test");
    if (darkMode !== "enabled") {
        // get the main content area
        var x = document.getElementById("content");
        x.style.backgroundColor = "rgb(20, 20, 20)";
        x.style.color = "#ddd";
        // get the navbar
        var y = document.getElementById("nav");
        y.style.backgroundColor = "rgb(100, 100, 100)";
        // get the navbar links
        var z = y.getElementsByTagName("a");
        var i;
        for (i = 0; i < z.length; i++) {
            z[i].style.color = "#ddd";
        }

        var active = y.getElementsByClassName("active");
        active[0].style.color = "#000";

        var title = document.getElementById("nav-title");
        title.style.color = "#ddd";

        var footer = document.getElementById("footer");
        footer.style.backgroundColor = "rgb(100, 100, 100)";
        footer.style.color = "#ddd";

        var sheet = document.styleSheets[1];
        if (hoverIndex) {
            sheet.deleteRule(hoverIndex);
        }
        hoverIndex = sheet.insertRule('#nav a:hover { background-color: #000; }', sheet.cssRules.length);

        var tiles = document.getElementsByClassName("quicklink");
        if (tiles) {
            var j;
            for (j = 0; j < tiles.length; j++) {
                tiles[j].style.backgroundColor = "rgb(100, 100, 100)";
                tiles[j].style.color = "#ddd";
                tiles[j].style.boxShadow = "5px 10px 7px rgba(50, 50, 50, 0.7)";
            }
        }

        var accords = document.getElementsByClassName("collapsible");
        if (accords) {
            var k;
            for (k = 0; k < accords.length; k++) {
                accords[k].style.backgroundColor = "rgb(20, 20, 20)";
                accords[k].style.color = "#ddd";
            }
        }
        localStorage.setItem("darkMode", "enabled");
        //console.log("dark mode enabled");
        darkMode = localStorage.getItem("darkMode");
    }
    else {
        // get the main content area
        var x = document.getElementById("content");
        x.style.backgroundColor = "rgb(255, 255, 230)";
        x.style.color = "#000";
        // get the navbar
        var y = document.getElementById("nav");
        y.style.backgroundColor = "rgb(255, 255, 255)";
        // get the navbar links
        var z = y.getElementsByTagName("a");
        var i;
        for (i = 0; i < z.length; i++) {
            z[i].style.color = "#000";
        }
        var title = document.getElementById("nav-title");
        title.style.color = "#000";

        var footer = document.getElementById("footer");
        footer.style.backgroundColor = "rgb(128, 213, 213)";
        footer.style.color = "#000";

        var sheet = document.styleSheets[1];
        if (hoverIndex) {
            sheet.deleteRule(hoverIndex);
        }
        hoverIndex = sheet.insertRule('#nav a:hover { background-color: #ddd; }', sheet.cssRules.length);

        var tiles = document.getElementsByClassName("quicklink");
        if (tiles) {
            var j;
            for (j = 0; j < tiles.length; j++) {
                tiles[j].style.backgroundColor = "rgb(128, 213, 213)";
                tiles[j].style.color = "#000";
                tiles[j].style.boxShadow = "5px 10px 7px rgba(100, 100, 100, 0.7)";
            }
        }

        var accords = document.getElementsByClassName("collapsible");
        if (accords) {
            var k;
            for (k = 0; k < accords.length; k++) {
                accords[k].style.backgroundColor = "rgb(255, 255, 230)";
                accords[k].style.color = "#000";
            }
        }

        localStorage.setItem("darkMode", null);
        //console.log("dark mode disabled");
        darkMode = localStorage.getItem("darkMode");
    }
}

// check if dark mode is enabled
$(window).on('load', function () {
    // loading functions for navbar -- not pretty but hopefully I'll find something better
    var path = window.location.pathname;
    var page = path.split("/").pop();
    if (page === "index.php") {
        var curntAct = document.getElementsByClassName("active");
        curntAct[0].className = "";
        var newAct = document.getElementById("home");
        newAct.className = "active";
    }
    else if (page === "DRD_Adv_Search.php") {
        var curntAct = document.getElementsByClassName("active");
        curntAct[0].className = "";
        var newAct = document.getElementById("adv-search");
        newAct.className = "active";
    }
    else if (page === "Author_Search.php") {
        var curntAct = document.getElementsByClassName("active");
        curntAct[0].className = "";
        var newAct = document.getElementById("browse");
        newAct.className = "active";
    }// remember to put recently added here when the link is made
    else if (page === "DRD_About.php") {
        var curntAct = document.getElementsByClassName("active");
        curntAct[0].className = "";
        var newAct = document.getElementById("about");
        newAct.className = "active";
    }
    else {
        var curntAct = document.getElementsByClassName("active");
        curntAct[0].className = "";
        var newAct = document.getElementById("home");
        newAct.className = "active";
    }

    // dark mode caching code
    var darkmode = localStorage.getItem("darkMode");
    if (darkmode !== "enabled") {
        var x = document.getElementById("content");
        x.style.backgroundColor = "rgb(255, 255, 230)";
        x.style.color = "#000";
        // get the navbar
        var y = document.getElementById("nav");
        y.style.backgroundColor = "rgb(255, 255, 255)";
        // get the navbar links
        var z = y.getElementsByTagName("a");
        var i;
        for (i = 0; i < z.length; i++) {
            z[i].style.color = "#000";
        }

        var title = document.getElementById("nav-title");
        title.style.color = "#000";
        var footer = document.getElementById("footer");
        footer.style.backgroundColor = "rgb(128, 213, 213)";
        footer.style.color = "#000";

        var sheet = document.styleSheets[1];
        hoverIndex = sheet.insertRule('#nav a:hover { background-color: #ddd; }', sheet.cssRules.length);

        var tiles = document.getElementsByClassName("quicklink");
        if (tiles) {
            var j;
            for (j = 0; j < tiles.length; j++) {
                tiles[j].style.backgroundColor = "rgb(128, 213, 213)";
                tiles[j].style.color = "#000";
                tiles[j].style.boxShadow = "5px 10px 7px rgba(100, 100, 100, 0.7)";
            }
        }

        var accords = document.getElementsByClassName("collapsible");
        if (accords) {
            var k;
            for (k = 0; k < accords.length; k++) {
                accords[k].style.backgroundColor = "rgb(255, 255, 230)";
                accords[k].style.color = "#000";
            }
        }
    }
    else {
        var checker = document.getElementById("night-check");
        checker.checked = true;
        var x = document.getElementById("content");
        x.style.backgroundColor = "rgb(20, 20, 20)";
        x.style.color = "#ddd";
        // get the navbar
        var y = document.getElementById("nav");
        y.style.backgroundColor = "rgb(100, 100, 100)";
        // get the navbar links
        var z = y.getElementsByTagName("a");
        var i;
        for (i = 0; i < z.length; i++) {
            z[i].style.color = "#ddd";
        }

        var active = y.getElementsByClassName("active");
        active[0].style.color = "#000";

        var title = document.getElementById("nav-title");
        title.style.color = "#ddd";

        var footer = document.getElementById("footer");
        footer.style.backgroundColor = "rgb(100, 100, 100)";
        footer.style.color = "#ddd";

        var sheet = document.styleSheets[1];
        hoverIndex = sheet.insertRule('#nav a:hover { background-color: #000; }', sheet.cssRules.length);

        var tiles = document.getElementsByClassName("quicklink");
        if (tiles) {
            var j;
            for (j = 0; j < tiles.length; j++) {
                tiles[j].style.backgroundColor = "rgb(100, 100, 100)";
                tiles[j].style.color = "#ddd";
                tiles[j].style.boxShadow = "5px 10px 7px rgba(50, 50, 50, 0.7)";
            }
        }

        var accords = document.getElementsByClassName("collapsible");
        if (accords) {
            var k;
            for (k = 0; k < accords.length; k++) {
                accords[k].style.backgroundColor = "rgb(20, 20, 20)";
                accords[k].style.color = "#ddd";
            }
        }
    }
});

